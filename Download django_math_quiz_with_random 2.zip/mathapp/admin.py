from django.contrib import admin
from .models import Topic, Question

admin.site.register(Topic)
admin.site.register(Question)
